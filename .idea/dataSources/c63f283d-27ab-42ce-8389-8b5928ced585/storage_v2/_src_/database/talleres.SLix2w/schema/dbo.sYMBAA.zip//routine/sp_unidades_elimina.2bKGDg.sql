create proc [dbo].[sp_unidades_elimina]
@codUnid int, @descripcion varchar(50), @status bit

as

if exists(select codUnid from unidades where codUnid = @codUnid)
	update unidades set status = 0 where codUnid = @codUnid

GO

