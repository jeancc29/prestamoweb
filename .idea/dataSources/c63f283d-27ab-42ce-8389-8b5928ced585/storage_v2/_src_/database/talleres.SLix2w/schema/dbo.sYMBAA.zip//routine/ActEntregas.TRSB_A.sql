CREATE proc [dbo].[ActEntregas]
 @codEmpl int, @codUsua int, @codProy int
as
--@codEntr int = null,
declare @codEntr int
--if @codEntr is null
--begin
	select @CodEntr = max(codEntr) from entregas
	if @CodEntr is null
		begin
			set @CodEntr = 0
		end
	set @CodEntr = @CodEntr + 1


	insert into entregas(codEntr, codEmpl, codUsua, codProy, fecha, status) values(@CodEntr,  @codEmpl, @codUsua, @codProy, GETDATE(), 0)
--end
--else
	--update entregas set codEmpl = @codEmpl, codUsua = @codUsua, codProy = @codProy where codEntr = @codEntr

select * from entregas where codEntr = @CodEntr


GO

