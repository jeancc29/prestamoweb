CREATE proc [dbo].[ActDetalles_entregas_e_impresion]
@CodEntr int, @CodArti int, @precio float, @cantidad float
as

insert into detalles_entregas(codEntr, codArti, precio, cantidad) values(@CodEntr, @CodArti, @precio, @cantidad)

update detalles_compras set canExi = canExi - @cantidad where codComp = (select codComp from detalles_compras where codArti = @CodArti and canExi = (select min(canExi) from detalles_compras where canExi >= 1))


select a.descripcion, de.cantidad, de.precio, em.nombre, p.descripcion, e.fecha from detalles_entregas de inner join articulos a on a.codArti = de.codArti
inner join entregas e on e.codEntr = de.codEntr
inner join empleados em on em.codEmpl = e.codEmpl
inner join proyectos p on p.codProy = e.codProy where e.codEntr = @CodEntr
GO

