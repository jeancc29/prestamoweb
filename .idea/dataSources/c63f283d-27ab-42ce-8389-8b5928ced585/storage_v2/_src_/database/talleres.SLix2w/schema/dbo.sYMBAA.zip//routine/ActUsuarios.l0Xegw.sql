create procedure [dbo].[ActUsuarios]
@CodUsua int, @nombres varchar(100), @direccion text, @usuario varchar(30), @pass varchar(30), @telefono varchar(9)
as
if @CodUsua <= 0
	begin 
		select @CodUsua = max(codUsua) from usuarios
		if @CodUsua is null set @CodUsua = 0
		set @CodUsua = @CodUsua + 1
	end
if exists(select codUsua from usuarios where CodUsua = @CodUsua)
	update usuarios set nombre = @nombres, direccion = @direccion, usuario = @usuario, pass =@pass, telefono = @telefono where codUsua = @CodUsua
else
	insert into usuarios(codUsua, nombre, direccion, usuario, pass, telefono) values(@CodUsua, @nombres, @direccion, @usuario, @pass, @telefono)
select * from usuarios

GO

