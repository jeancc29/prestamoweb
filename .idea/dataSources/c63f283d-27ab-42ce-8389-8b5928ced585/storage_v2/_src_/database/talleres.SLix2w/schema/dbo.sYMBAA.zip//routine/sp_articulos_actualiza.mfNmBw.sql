create procedure [dbo].[sp_articulos_actualiza]
@CodArti int, @descripcion varchar(100), @precomp float, @canexi int, @punreo int, @codUnid int
as
if @CodArti <= 0
	begin 
		select @CodArti = max(codArti) from articulos
		if @CodArti is null set @CodArti = 0
		set @CodArti = @CodArti + 1
	end
if exists(select codArti from articulos where codArti = @CodArti)
	update articulos set descripcion = @descripcion, preComp = @precomp, canExi = @canexi, punReo =@punreo, codUnid = @codUnid where codArti = @CodArti
else
	insert into articulos(codArti, descripcion, preComp,canExi, punReo, codUnid) values(@CodArti, @descripcion, @precomp, @canexi, @punreo, @codUnid)
select * from articulos
GO

