create proc pruebaArticulos
@codArti int

as

select * from articulos where codArti = @codArti
GO

