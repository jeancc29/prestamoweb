CREATE proc [dbo].[ActDetalles_entregas]
@CodEntr int, @CodArti int, @precio float, @cantidad float

as

--if not exists( select codEntr from detalles_entregas where codEntr = @CodEntr and codArti = @CodArti)
--begin
	insert into detalles_entregas(codEntr, codArti, precio, cantidad) values(@CodEntr, @CodArti, @precio, @cantidad)

	update detalles_compras set canExi = canExi - @cantidad where codComp = (select codComp from detalles_compras where codArti = @CodArti and canExi = (select min(canExi) from detalles_compras where canExi >= 1))
--end
--else
	--begin
		--update detalles_compras set canExi = ABS( (select cantidad from detalles_entregas where codEntr = @CodEntr and codArti = @CodArti) - @cantidad) where codComp = (select codComp from detalles_compras where codArti = @CodArti and canExi = (select min(canExi) from detalles_compras where canExi >= 1))
		--update detalles_entregas set cantidad = @cantidad, precio = @precio where codEntr = @CodEntr and codArti = @CodArti
	--end

select a.descripcion as desc_articulo, concat(de.cantidad, ' ', uni.descripcion) as cantidad_y_unidad, de.precio, em.nombre, p.descripcion, e.fecha, u.nombre as nom_usuario, e.codEntr from detalles_entregas de inner join articulos a on a.codArti = de.codArti
inner join entregas e on e.codEntr = de.codEntr
inner join empleados em on em.codEmpl = e.codEmpl
inner join usuarios u on u.codUsua = e.codUsua
inner join unidades uni on uni.codUnid = a.codUnid
inner join proyectos p on p.codProy = e.codProy where e.codEntr = @CodEntr


GO

