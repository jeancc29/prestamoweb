
CREATE view vwentregas 
as
select distinct e.codEntr, p.descripcion proyecto, em.nombre empleado,  stuff(( select ', ' + concat(de.cantidad, ' ',a.descripcion)  from entregas entre inner join detalles_entregas de on entre.codEntr = de.codEntr
inner join proyectos p on p.codProy = entre.codProy
inner join articulos a on a.codArti = de.codArti
inner join empleados em on entre.codEmpl = em.codEmpl  where entre.codEntr = e.codEntr  for xml path('')), 1, 1, '') as articulos, e.fecha from entregas e inner join detalles_entregas de on e.codEntr = de.codEntr
inner join proyectos p on p.codProy = e.codProy
inner join articulos a on a.codArti = de.codArti
inner join empleados em on e.codEmpl = em.codEmpl where e.status = 0


GO

