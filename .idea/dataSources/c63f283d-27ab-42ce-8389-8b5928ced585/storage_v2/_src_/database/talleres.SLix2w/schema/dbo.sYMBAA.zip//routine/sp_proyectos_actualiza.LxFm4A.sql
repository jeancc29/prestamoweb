create procedure [dbo].[sp_proyectos_actualiza]
@CodProy int, @descripcion varchar(100), @status bit
as
if @CodProy <= 0
	begin 
		select @CodProy = max(codProy) from proyectos
		if @CodProy is null set @CodProy = 0
		set @CodProy = @CodProy + 1
	end
if exists(select codProy from proyectos where codProy = @CodProy)
	update proyectos set descripcion = @descripcion, status = @status where codProy = @CodProy
else
	insert into proyectos(codProy, descripcion, status) values(@CodProy, @descripcion, @status)
select * from proyectos
GO

