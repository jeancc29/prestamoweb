create procedure [dbo].[sp_suplidores_elimina]
@CodSupl int, @descripcion varchar(100), @status bit
as
if @CodSupl <= 0
	begin 
		select @CodSupl = max(codSupl) from suplidores
		if @CodSupl is null set @CodSupl = 0
		set @CodSupl = @CodSupl + 1
	end
if exists(select codSupl from suplidores where codSupl = @CodSupl)
	update suplidores set status = 0 where codSupl = @CodSupl

select * from suplidores

GO

