create procedure [dbo].[sp_empleados_actualiza]
@CodEmpl int, @descripcion varchar(100), @status bit
as
if @CodEmpl <= 0
	begin 
		select @CodEmpl = max(codEmpl) from empleados
		if @CodEmpl is null set @CodEmpl = 0
		set @CodEmpl = @CodEmpl + 1
	end
if exists(select codEmpl from empleados where codEmpl = @CodEmpl)
	update empleados set nombre = @descripcion, status = @status where codEmpl = @CodEmpl
else
	insert into empleados(codEmpl, nombre, status) values(@CodEmpl, @descripcion, @status)
select * from empleados

GO

