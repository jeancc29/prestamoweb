CREATE proc [dbo].[infoArticulos]
@codArti int

as


if exists( select a.descripcion, sum(c.canExi) as canExi, max(c.preComp) preComp from articulos a inner join detalles_compras c on a.codArti = c.codArti where a.codArti = @codArti group by a.descripcion)
	begin
		select a.codArti, a.descripcion, sum(c.canExi) as canExi, max(c.preComp) preComp, a.punReo, u.descripcion as unidad, u.codUnid from articulos a inner join detalles_compras c on a.codArti = c.codArti inner join unidades u on a.codUnid = u.codUnid where a.codArti = @codArti group by a.descripcion, a.punReo, u.descripcion, u.codUnid, a.codArti
	end
else
	select a.codArti, a.descripcion, preComp = 0, canExi = 0, punReo, u.descripcion as unidad, u.codUnid from articulos a inner join unidades u on a.codUnid = u.codUnid where codArti = @codArti

	print @codArti
GO

