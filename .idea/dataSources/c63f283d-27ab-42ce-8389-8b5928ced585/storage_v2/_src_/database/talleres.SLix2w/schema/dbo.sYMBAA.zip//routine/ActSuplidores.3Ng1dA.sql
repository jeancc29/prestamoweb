create procedure [dbo].[ActSuplidores]
@CodSupl int, @descripcion varchar(100), @status bit
as
if @CodSupl <= 0
	begin 
		select @CodSupl = max(codSupl) from suplidores
		if @CodSupl is null set @CodSupl = 0
		set @CodSupl = @CodSupl + 1
	end
if exists(select codSupl from suplidores where codSupl = @CodSupl)
	update suplidores set descripcion = @descripcion, status = @status where codSupl = @CodSupl
else
	insert into suplidores(codSupl, descripcion, status) values(@CodSupl, @descripcion, @status)
select * from suplidores

GO

