CREATE view vwentregasReportes
as

SELECT DISTINCT e.codEntr, p.descripcion AS proyecto, p.codProy, em.nombre AS empleado, em.codEmpl, a.descripcion AS articulos, a.codArti, de.cantidad, u.descripcion unidad, e.fecha
FROM            dbo.entregas AS e INNER JOIN
                         dbo.detalles_entregas AS de ON e.codEntr = de.codEntr INNER JOIN
                         dbo.proyectos AS p ON p.codProy = e.codProy INNER JOIN
                         dbo.articulos AS a ON a.codArti = de.codArti INNER JOIN
                         dbo.empleados AS em ON e.codEmpl = em.codEmpl
						 inner join unidades u on u.codUnid = a.codUnid
WHERE        (e.status = 0)
GO
