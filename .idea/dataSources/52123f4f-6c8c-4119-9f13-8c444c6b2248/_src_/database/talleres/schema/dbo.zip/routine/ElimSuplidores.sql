create proc [dbo].[ElimSuplidores]
@codSupl int

as

delete from suplidores where codSupl= @codSupl
GO
