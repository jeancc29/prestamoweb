create procedure [dbo].[sp_empleados_elimina]
@CodEmpl int
as
	if exists(select codEmpl from empleados where codEmpl = @CodEmpl)
		update empleados set status = 0 where codEmpl = @CodEmpl


GO
