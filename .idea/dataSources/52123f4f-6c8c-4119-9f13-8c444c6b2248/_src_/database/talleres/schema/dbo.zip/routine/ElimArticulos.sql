create proc ElimArticulos
@codArti int

as

delete from articulos where codArti = @codArti
GO
