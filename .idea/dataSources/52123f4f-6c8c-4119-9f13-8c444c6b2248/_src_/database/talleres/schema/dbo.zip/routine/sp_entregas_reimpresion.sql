CREATE proc [dbo].[sp_entregas_reimpresion]
@CodEntr int
as

select a.descripcion as desc_articulo, concat(de.cantidad, ' ', uni.descripcion) as cantidad_y_unidad, de.precio, em.nombre, p.descripcion, e.fecha, u.nombre as nom_usuario, e.codEntr from detalles_entregas de inner join articulos a on a.codArti = de.codArti
inner join entregas e on e.codEntr = de.codEntr
inner join empleados em on em.codEmpl = e.codEmpl
inner join usuarios u on u.codUsua = e.codUsua
inner join unidades uni on uni.codUnid = a.codUnid
inner join proyectos p on p.codProy = e.codProy where e.codEntr = @CodEntr
GO
