CREATE proc [dbo].[buscarArticulos]
@busqueda varchar(100)

as

if exists( select a.descripcion, sum(c.canExi) as canExi, max(c.preComp) preComp from articulos a inner join detalles_compras c on a.codArti = c.codArti where a.descripcion like '%'+@busqueda+'%' group by a.descripcion)
	begin
		select a.descripcion, sum(c.canExi) as canExi, max(c.preComp) preComp, a.punReo, u.descripcion as unidad from articulos a inner join detalles_compras c on a.codArti = c.codArti inner join unidades u on a.codUnid = u.codUnid where a.descripcion like '%'+@busqueda+'%' group by a.descripcion, a.punReo, u.descripcion
	end
else
	select a.descripcion, preComp = 0, canExi = 0, punReo, u.descripcion from articulos a inner join unidades u on a.codUnid = u.codUnid where a.descripcion like '%'+@busqueda+'%'
GO
