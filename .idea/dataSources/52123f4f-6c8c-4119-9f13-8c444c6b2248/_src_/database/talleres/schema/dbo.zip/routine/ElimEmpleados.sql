create proc [dbo].[ElimEmpleados]
@codEmpl int

as

delete from empleados where codEmpl= @codEmpl
GO
