create procedure [dbo].[sp_empleados_insertar]
@CodEmpl int, @descripcion varchar(100), @status bit
as
if @CodEmpl <= 0
	begin 
		select @CodEmpl = max(codEmpl) from empleados
		if @CodEmpl is null set @CodEmpl = 0
		set @CodEmpl = @CodEmpl + 1
	end
if not exists(select codEmpl from empleados where codEmpl = @CodEmpl)
	insert into empleados(codEmpl, nombre, status) values(@CodEmpl, @descripcion, @status)
else
	begin

	select 'Error el codigo existe'
	
	end

GO
