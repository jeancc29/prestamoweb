CREATE proc [dbo].[ActCompras]
@CodSupl int
as
declare @CodComp int
select @CodComp = max(codComp) from compras
if @CodComp is null
	begin
		set @CodComp = 0
	end
set @CodComp = @CodComp + 1


insert into compras(codComp, CodSupl, fecha) values(@CodComp, @CodSupl, GETDATE())
select * from compras where codComp = @CodComp


GO
