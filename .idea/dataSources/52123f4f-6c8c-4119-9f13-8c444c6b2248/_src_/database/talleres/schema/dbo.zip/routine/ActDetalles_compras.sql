create proc [dbo].[ActDetalles_compras]
@CodComp int, @CodArti int, @precio float, @cantidad int
as

insert into detalles_compras(codComp, codArti, preComp, canComp, canExi) values(@CodComp, @CodArti, @precio, @cantidad, @cantidad)

select * from detalles_compras
GO
