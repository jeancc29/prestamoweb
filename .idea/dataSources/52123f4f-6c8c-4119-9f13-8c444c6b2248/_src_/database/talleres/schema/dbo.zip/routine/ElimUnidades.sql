create proc ElimUnidades
@codUnid int

as

delete from unidades where codUnid = @codUnid
GO
