create proc [dbo].[sp_unidades_actualiza]
@codUnid int, @descripcion varchar(50), @status bit

as

if @codUnid <= 0
begin
	select @codUnid = max(codUnid) from unidades
	if @codUnid is null set @codUnid = 0
	set @codUnid = @codUnid + 1
end
if exists(select codUnid from unidades where codUnid = @codUnid)
	update unidades set descripcion = @descripcion, status = @status where codUnid = @codUnid
else
	insert into unidades(codUnid, descripcion, status) values(@codUnid, @descripcion, @status)
GO
