create proc sp_clientes_eliminar
@id int
as
set nocount on
if exists(select codigo_usuario from usuarios where codigo_usuario = @id)
	begin
		update usuarios set estado = 0 where codigo_usuario = @id
		select 'el cliente se ha eliminado correctamente' as info
	end
else
	select 'El cliente no existe' as info
GO
