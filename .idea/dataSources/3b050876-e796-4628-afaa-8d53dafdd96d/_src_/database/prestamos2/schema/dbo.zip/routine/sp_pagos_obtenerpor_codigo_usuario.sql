CREATE proc sp_pagos_obtenerpor_codigo_usuario
@codigo_usuario int
as


	select *, (select sum(monto) from documentos where id_registro_afecta = d.id_registro_afecta) as monto_pagado, 
		(select sum(cuota) from vw_pagos_consulta where id_prestamo = d.id_registro_afecta) as balance_pendiente,
		(select count(cuota) from vw_pagos_consulta where id_prestamo = d.id_registro_afecta and cuota = 0) as cuotas_pagadas,
		(select (sum(interes) - sum(interes_pagado)) from vw_pagos_consulta where id_prestamo = d.id_registro_afecta) as interes_pendiente
	  from documentos d inner join 
	tipos_registros t on t.tipo_registro = d.tipo_registro_documento inner join
	usuarios u on u.codigo_usuario = d.codigo_usuario
	 where t.descripcion = 'pago' and d.codigo_usuario= @codigo_usuario
GO
