CREATE view vw_pagos
as




select idAmortizacion, 
			fecha_pago,
			numero_cuota, 
			cuota = 
				case 
					when (select  (a.cuota - sum(d.monto)) from documentos d where d.id_registro_afecta = a.id_prestamo and d.idAmortizacion = a.idAmortizacion) is null then a.cuota
					else (select  (a.cuota - sum(d.monto)) from documentos d where d.id_registro_afecta = a.id_prestamo and d.idAmortizacion = a.idAmortizacion) 
				end, 
			capital, 
			interes, 
			balance, 
			id_prestamo,
			(select mora from documentos d where d.id_registro = a.id_prestamo) as mora_porcentaje,
			mora_perdonada = 
				case
					when (select top 1 mora_perdonada from documentos d where d.idAmortizacion = a.idAmortizacion) is null then 0
					else (select top 1 mora_perdonada from documentos d where d.idAmortizacion = a.idAmortizacion)
				end
	from amortizacion a
	where a.idAmortizacion not in (select d.idAmortizacion from documentos d where   d.id_registro_afecta = a.id_prestamo group by idAmortizacion, d.mora having sum(d.monto) >= (a.cuota+d.mora))






--select idAmortizacion, 
--			fecha_pago, 
--			cuota = 
--				case 
--					when (select  (a.cuota - sum(d.monto)) from documentos d where d.id_registro_afecta = a.id_prestamo and d.idAmortizacion = a.idAmortizacion) is null then a.cuota
--					else (select  (a.cuota - sum(d.monto)) from documentos d where d.id_registro_afecta = a.id_prestamo and d.idAmortizacion = a.idAmortizacion) 
--				end, 
--			capital, 
--			interes, 
--			balance, 
--			id_prestamo,
--			(select mora from documentos d where d.id_registro = a.id_prestamo) as mora_porcentaje,
--			mora_perdonada = 
--				case
--					when (select top 1 mora_perdonada from documentos d where d.idAmortizacion = a.idAmortizacion) is null then 0
--					else (select top 1 mora_perdonada from documentos d where d.idAmortizacion = a.idAmortizacion)
--				end
--	from amortizacion a
--	where a.idAmortizacion not in (select d.idAmortizacion from documentos d where d.monto >= (a.cuota + d.mora) and d.id_registro_afecta = a.id_prestamo)

	/*	(select d.idAmortizacion from documentos d where d.monto >= a.cuota and d.mora_perdonada = 1) 
		Este subquery que esta en la sentencia where me retornara de la tabla documentos
		los idAmortizacion que sus montos son mayores o iguales que las cuotas de la tabla amortizacion,
		en pocas palabras los idAmortizacion que se han pagado completamente */

	/*	(select  (a.cuota - d.monto) from documentos d where d.id_registro_afecta = a.id_prestamo and d.idAmortizacion = a.idAmortizacion)
		Este subquery me va a retornar la diferencia entre la cuota de la tabla amortizacion y el monto abonado de la tabla documento,
		En pocas palabras me va a retornar el resto de la cuota que se debe pagar */






/*select 
	--ROW_NUMBER() OVER(ORDER BY a.idAmortizacion ASC) AS fila,
	distinct a.idAmortizacion,
	a.id_prestamo, 
	a.fecha_pago, 
	cuota =
		case 
			when d.monto is null then a.cuota
			when d.monto < a.cuota then a.cuota - d.monto
			else 0
		end , 
	a.capital, 
	a.interes, 
	a.balance, 
	pagado = 
		case 
			when d.monto is null then 'no'
			when d.monto < a.cuota then 'abono'
			else 'pagado'
		end ,
	d.mora as mora_porcentaje
from amortizacion a 
left join documentos d on d.id_registro_afecta = a.id_prestamo */




/* El id_registro_afecta va a contener el numero de documento 
	al que afecta, en este caso sera el id o # de prestamo, por esta
	razon los pagos y los prestamos estaran relacionados por este campo(id_registro_afecta) */

GO
