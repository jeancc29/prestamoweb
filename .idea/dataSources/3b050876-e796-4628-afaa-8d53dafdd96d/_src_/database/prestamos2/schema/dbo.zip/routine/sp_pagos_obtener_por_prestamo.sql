create proc sp_pagos_obtener_por_prestamo
@idPrestamo int
as
declare @id int
select * from documentos d inner join 
	tipos_registros t on d.tipo_registro_documento = t.tipo_registro
	inner join amortizacion a on a.id_prestamo = d.id_registro
where t.renglon = 'documento' and t.descripcion = 'pago' and d.monto < a.cuota and d.id_registro = @idPrestamo
GO
