CREATE proc sp_prestamos_actualizar
@id_registro int = null,
@tipo_registro_documento int = 0,
@documento varchar(20) = '',
@fecha date = '1900-01-01',
@codigo_usuario int = 0,
@codigo_usuario_registro int = 0,
@capital decimal(20,2) = 0,
@porciento_interes decimal(6,2) = 0,
@cantidad_cuotas decimal(20, 2) = 0,
@valor_cuotas decimal(20, 2) = 0,
@codigo_usuario_garante int = 0,
@monto_prestamo decimal(20, 2) = 0,
@tipo_registro_sucursal int = 1,
@estado bit = 0,
@completado bit = 0,
@tipo_prestamo int = 1,
@detalle text = '',
@formapago int = 4,
@mora_porcentaje int = 0,
@tipo_interes int = 0

as
set nocount on

declare @numero_documento varchar(20)
declare @secuencia_actual varchar(20)
declare @posicion int
set @numero_documento = '0000000000'

if not exists(select id_registro from documentos where id_registro = @id_registro) or @id_registro is null
	begin
		select @tipo_registro_documento = tipo_registro from tipos_registros where renglon = 'documento' and descripcion = 'prestamo'
		select @id_registro = max(id_registro), @documento = max(id_registro) from documentos
		if @id_registro is null set @id_registro = 0
		set @id_registro = @id_registro + 1
		if @documento is null set @documento = 0
		set @documento = @documento + 1


		if exists(select idSecuencia from secuencias where secuencia_inicial = 'pre')
			begin
				update secuencias set secuencia_actual = secuencia_actual + 1 where secuencia_inicial = 'pre'
				select @secuencia_actual = max(secuencia_actual) from secuencias where secuencia_inicial = 'pre'
				set @posicion = len(@secuencia_actual)
				set @documento = substring(@numero_documento, @posicion, 10)
				set @documento = @documento + @secuencia_actual
			end
		else
			begin
				insert into secuencias(secuencia_inicial, secuencia_actual) values('pre', 1)
				set @secuencia_actual = '1'
				set @posicion = len(@secuencia_actual)
				set @documento = substring(@numero_documento, @posicion, 10)
				set @documento = @documento + @secuencia_actual
			end

		
		insert into documentos
			(id_registro,
			 tipo_registro_documento,
			 documento,
			 fecha,
			 codigo_usuario,
			 codigo_usuario_registro,
			 capital,
			 porciento_interes,
			 cantidad_cuotas,
			 codigo_usuario_garante,
			 monto_prestamo,
			 tipo_registro_sucursal,
			 completado,
			 tipo_registro_tipoprestamo,
			 formapago,
			 mora,
			 detalle,
			 id_registro_afecta
			 )
		values
			(@id_registro,
			 @tipo_registro_documento,
			 @documento,
			 @fecha,
			 @codigo_usuario,
			 @codigo_usuario_registro,
			 @capital,
			 @porciento_interes,
			 @cantidad_cuotas,
			 @codigo_usuario_garante,
			 @monto_prestamo,
			 @tipo_registro_sucursal,
			 @completado,
			 @tipo_prestamo,
			 @formapago,
			 @mora_porcentaje,
			 @detalle,
			 @id_registro
			 )

			 exec sp_prestamo_amortizacion_guardar @cuotas=@cantidad_cuotas, @monto=@monto_prestamo, @tipo_prestamo=@tipo_prestamo, @tasa=@porciento_interes, @idPrestamo = @id_registro, @formapago = @formapago, @fecha_pago = @fecha
			 select 'El prestamo se ha guardado correctamente', @formapago as formapago, @documento as documento, len(@secuencia_actual) tamano
	end
GO
