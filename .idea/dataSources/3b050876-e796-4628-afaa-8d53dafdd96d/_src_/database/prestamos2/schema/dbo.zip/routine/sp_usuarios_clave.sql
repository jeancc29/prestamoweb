create proc sp_usuarios_clave
@codigo_usuario int = null,
@usuario varchar(100) = '',
@clave varchar(20) = ''

as
set nocount on

if exists(select codigo_usuario from usuarios where codigo_usuario = @codigo_usuario)
	begin
		update usuarios set clave = @clave, login = @usuario where codigo_usuario = @codigo_usuario
		select 'Se ha guardado el usuario correctamente'
	end
else
	select 'El usuario no existe'
GO
