

CREATE FUNCTION dbo.calcularMora(@balance decimal(20, 2), @mora_porcentaje decimal(6,2), @fecha_pagar date, @idAmortizacion int)  
RETURNS decimal(20, 2)   
AS   
-- Returns the stock level for the product.  
BEGIN  
    DECLARE @diasDiferencias int; 
	DECLARE @mora_total decimal(20, 2); 
	DECLARE @montopagado decimal(20, 2);
	DECLARE @totalApagar decimal(20, 2);
	DECLARE @mora_perdonada bit
	set @diasDiferencias = datediff(day, cast(@fecha_pagar as date) , cast(GETDATE() as date))
	set @mora_porcentaje = cast((@mora_porcentaje/100) as decimal(20, 2));
    if @diasDiferencias > 0
		begin
			/* Lo que hago aqui abajo es, verificar si el montopagado es mayor que el total que se devería pagar que es(capital + interes),
			   si es mayor, entonces esto quiere decir que el deudor a pagado parte de la mora total que debe pagar, entonces lo que hago
			   es restar el abono de mora que se ha pagado al total de la mora a pagar, el abono de la mora que se ha pagado es (@montopagado - @totalApagar)) */
			select @montopagado = sum(monto), @mora_perdonada = mora_perdonada from documentos where idAmortizacion = @idAmortizacion group by mora_perdonada

			if @mora_perdonada = 1
				set @mora_total = 0
			else
				begin
					select @totalApagar = (capital + interes) from amortizacion where idAmortizacion = @idAmortizacion
					if @montopagado > @totalApagar
						set @mora_total = (@balance *  @mora_porcentaje) - (@montopagado - @totalApagar)
					else
						set @mora_total = (@balance *  @mora_porcentaje)
				end
		end
	else
		set @mora_total = 0;
    RETURN @mora_total;  
END;


GO
