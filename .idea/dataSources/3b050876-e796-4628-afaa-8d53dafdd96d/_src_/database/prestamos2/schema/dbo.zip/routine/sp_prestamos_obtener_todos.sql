CREATE proc sp_prestamos_obtener_todos
as

	select *,(select sum(monto) from documentos where id_registro_afecta = d.id_registro) as monto_pagado, 
		(select sum(cuota) from vw_pagos_consulta where id_prestamo = d.id_registro) as balance_pendiente,
		(select count(cuota) from vw_pagos_consulta where id_prestamo = d.id_registro and cuota = 0) as cuotas_pagadas,
		(select (sum(interes) - sum(interes_pagado)) from vw_pagos_consulta where id_prestamo = d.id_registro) as interes_pendiente,
		fecha_ultimo_pago =
				case
					when (select max(fecha) from documentos where id_registro_afecta = d.id_registro and idAmortizacion > 0) is not null then cast((select max(fecha) from documentos where id_registro_afecta = d.id_registro and idAmortizacion > 0) as varchar(20))
					else 'No tiene'
				end, 
	pagado =
		case
			when (select sum(p.cuota) from vw_pagos_consulta p where p.id_prestamo = d.id_registro) = 0 then 'pagado'
			else 'no'
		end
	from documentos d inner join 
	tipos_registros t on t.tipo_registro = d.tipo_registro_documento inner join
	usuarios u on u.codigo_usuario = d.codigo_usuario
	 where t.descripcion = 'prestamo'
GO
