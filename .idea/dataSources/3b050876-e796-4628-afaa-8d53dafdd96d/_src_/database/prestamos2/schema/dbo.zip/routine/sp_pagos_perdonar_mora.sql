create proc sp_pagos_perdonar_mora
@idAmortizacion int,
@perdonar Bit
as
begin
	set nocount on
	update documentos set mora_perdonada = @perdonar where idAmortizacion = @idAmortizacion
	select 'Se ha perdonado correctamente'
end
GO
