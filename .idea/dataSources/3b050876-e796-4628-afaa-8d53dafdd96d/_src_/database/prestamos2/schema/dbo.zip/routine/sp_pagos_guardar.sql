CREATE proc sp_pagos_guardar
@id_registro int = null,
@tipo_registro_documento int = 0,
@documento int = 0,
@fecha date = '1900-01-01',
@hora varchar(10) = '1',
@codigo_usuario int = 0,
@codigo_usuario_registro int = 0,
@capital decimal(20,2) = 0,
@interes decimal(6,2) = 0,
@efectivo decimal(20,2) = 0,
@cheque decimal(20,2) = 0,
@tarjeta decimal(20,2) = 0,
@mora decimal(20,2) = 0,
@paga_mora bit = 0,
@cantidad_cuotas decimal(20, 2) = 0,
@valor_cuotas decimal(20, 2) = 0,
@monto decimal(20, 2) = 0,
@balance decimal(20, 2) = 0,
@completado bit = 0,
@id_registro_afecta int = 0,
@idAmortizacion int = 0,
@mora_perdonada bit = 0

as
set nocount on
set @fecha = GETDATE()
set @hora =  cast(DATEPART(HOUR, GETDATE()) as varchar(2)) + ':' + cast(DATEPART(minute, GETDATE()) as varchar(2)) + ':' + cast(DATEPART(second, GETDATE()) as varchar(2));
if not exists(select id_registro from documentos where id_registro = @id_registro) or @id_registro is null
	begin
		if @idAmortizacion != 0 and exists(select idAmortizacion from documentos where idAmortizacion = @idAmortizacion)
			begin
				
				update documentos set mora_perdonada = @mora_perdonada, mora = @mora where idAmortizacion = @idAmortizacion
			end
		select @tipo_registro_documento = tipo_registro from tipos_registros where renglon = 'documento' and descripcion = 'pago'
		select @id_registro = max(id_registro) from documentos
		if @id_registro is null set @id_registro = 0
		set @id_registro = @id_registro + 1

			insert into documentos
				(id_registro,
				tipo_registro_documento,
				documento,
				fecha,
				hora,
				codigo_usuario,
				codigo_usuario_registro,
				capital,
				interes,
				efectivo,
				cheque,
				tarjeta,
				mora,
				paga_mora,
				cantidad_cuotas,
				valor_cuotas,
				monto,
				balance,
				completado,
				id_registro_afecta,
				idAmortizacion,
				mora_perdonada
				 )
			values
				(@id_registro,
				@tipo_registro_documento,
				@documento,
				@fecha,
				@hora,
				@codigo_usuario,
				@codigo_usuario_registro,
				@capital,
				@interes,
				@efectivo,
				@cheque,
				@tarjeta,
				@mora,
				@paga_mora,
				@cantidad_cuotas,
				@valor_cuotas,
				@monto,
				@balance,
				@completado,
				@id_registro_afecta,
				@idAmortizacion,
				@mora_perdonada
				 )
			
		
			 select 'El prestamo se ha pagado correctamente'
	end
GO
