CREATE proc [dbo].[sp_usuarios_acceder]
 @usuario varchar(20) = null,
 @clave varchar(200) = null

 as

 set nocount on
 declare @tipo_usuario varchar(20)
 if exists(select login from usuarios where login = @usuario)
	begin
		if exists(select login from usuarios where login = @usuario and clave = @clave)
			begin
				select @tipo_usuario = t.descripcion from usuarios u inner join tipos_registros t on u.tipo_registro_usuario = t.tipo_registro where u.login = @usuario
				select 0 as error, 'los datos son correctos' as info, codigo_usuario, nombre, @tipo_usuario tipo_usuario, login from usuarios where login = @usuario
			end
		else
			select 1 as error, 'Contraseña incorrecta' as info
	end
else
	select 1 as error, 'Usuario incorrecto' as info

GO
