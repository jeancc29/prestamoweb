
CREATE proc sp_pagos_buscar_para_cliente
 @datos varchar(50),
 @codigo_usuario int
as
set nocount on
SELECT  * ,(select sum(monto) from documentos where id_registro_afecta = d.id_registro_afecta) as monto_pagado, 
		(select sum(cuota) from vw_pagos_consulta where id_prestamo = d.id_registro_afecta) as balance_pendiente,
		(select count(cuota) from vw_pagos_consulta where id_prestamo = d.id_registro_afecta and cuota = 0) as cuotas_pagadas,
		(select (sum(interes) - sum(interes_pagado)) from vw_pagos_consulta where id_prestamo = d.id_registro_afecta) as interes_pendiente
	FROM documentos d INNER JOIN 
	tipos_registros t ON d.tipo_registro_documento = t.tipo_registro inner join
	usuarios u on u.codigo_usuario = d.codigo_usuario
WHERE d.codigo_usuario = @codigo_usuario and t.renglon = 'documento' and t.descripcion = 'pago' and (d.fecha like '%' + @datos + '%' or u.nombre  like '%' + @datos + '%' or d.documento like '%' + @datos + '%')

GO
