CREATE proc sp_prestamo_amortizacion
 @cuotas int,
 @monto decimal(20, 2),
 @tipo_prestamo int,
 @tasa int,
 @formapago int,
 @fecha_pago datetime2 = getdate

 as

 set nocount on
declare @p decimal(20, 12)
declare @i decimal(2, 2)
declare @t table(fecha_pago date, cuota decimal(20, 2), capital decimal(20, 2), interes decimal(20, 2), balance decimal(20, 2))

declare @i_temporal decimal(20, 10) = 0
declare @monto_temporal decimal(20, 10) = 1
declare @amortizacion_temporal decimal(20, 10) = 0
declare @contador int = 0


-- set @a = 4000 *  ((0.42/6) / ( (1-power((1+(0.42/6)), -6) )))

/************************* METODO SOLUTO(Pago e interes fijos) ********************************/
if @tipo_prestamo = 1
	begin
		set @i = cast(@tasa as float) / cast(100 as float)
		set @i_temporal = @monto * (@i / @cuotas)
		set @p = @i_temporal + (cast(@monto as float) / cast(@cuotas as float))
		


		WHILE (@contador <= @cuotas)
		BEGIN
		if @contador > 0
			begin
				set @amortizacion_temporal = @p - @i_temporal;
				set @monto_temporal = @monto_temporal - @amortizacion_temporal

				if @formapago = 1 set  @fecha_pago = DATEADD(day,1,@fecha_pago)  --Esta funcion sirve para sumarle un mes, año, dia, segundo, etc. a la fecha establecida
				else if @formapago = 2 set  @fecha_pago = DATEADD(week,1,@fecha_pago)
				else if @formapago = 3 set  @fecha_pago = DATEADD(week,2,@fecha_pago)
				else if @formapago = 4 set  @fecha_pago = DATEADD(MONTH,1,@fecha_pago)
				else if @formapago = 5 set  @fecha_pago = DATEADD(YEAR,1,@fecha_pago)

				insert into @t values(@fecha_pago, @p, @amortizacion_temporal, @i_temporal, @monto_temporal)
			end
		else
			begin
				insert into @t values(@fecha_pago, 0, 0, 0, @monto)
				set @monto_temporal = @monto
			end
			set @contador = @contador + 1
		END
	end


/************************* METODO INSOLUTO(Amortizacion francesa) ********************************/
if @tipo_prestamo = 2
	begin
		set @i = cast(@tasa as float) / cast(100 as float)
		set @p = @monto *  ((@i/@cuotas) / ( (1-power((1+(@i/@cuotas)), -@cuotas) ))) 

		/*declare @i_temporal decimal(20, 10) = 0
		declare @monto_temporal decimal(20, 10) = 1
		declare @amortizacion_temporal decimal(20, 10) = 0
		declare @contador int = 0 */

		WHILE (@contador <= @cuotas)
		BEGIN
		if @contador > 0
			begin
				set @i_temporal = @monto_temporal * (@i / @cuotas)
				set @amortizacion_temporal = @p - @i_temporal;
				set @monto_temporal = @monto_temporal - @amortizacion_temporal

				if @formapago = 1 set  @fecha_pago = DATEADD(day,1,@fecha_pago)  --Esta funcion sirve para sumarle un mes, año, dia, segundo, etc. a la fecha establecida
				else if @formapago = 2 set  @fecha_pago = DATEADD(week,1,@fecha_pago)
				else if @formapago = 3 set  @fecha_pago = DATEADD(week,2,@fecha_pago)
				else if @formapago = 4 set  @fecha_pago = DATEADD(MONTH,1,@fecha_pago)
				else if @formapago = 5 set  @fecha_pago = DATEADD(YEAR,1,@fecha_pago)

				insert into @t values(@fecha_pago, @p, @amortizacion_temporal, @i_temporal, @monto_temporal)
			end
		else
			begin
				insert into @t values(@fecha_pago, 0, 0, 0, @monto)
				set @monto_temporal = @monto
			end
			set @contador = @contador + 1
		END
	end




/************************* METODO AMORTIZACION FIJA(Amortizacion Aleman) ********************************/
if @tipo_prestamo = 3
	begin
		set @i = cast(@tasa as float) / cast(100 as float)
		set @p = @i_temporal + (cast(@monto as float) / cast(@cuotas as float))
		set @amortizacion_temporal = @p - @i_temporal;

		/*declare @i_temporal decimal(20, 10) = 0
		declare @monto_temporal decimal(20, 10) = 1
		declare @amortizacion_temporal decimal(20, 10) = 0
		declare @contador int = 0 */

		WHILE (@contador <= @cuotas)
		BEGIN
		if @contador > 0
			begin
				set @i_temporal = @monto_temporal * (@i / @cuotas)
				set @p = @i_temporal + @amortizacion_temporal
				set @monto_temporal = @monto_temporal - @amortizacion_temporal

				if @formapago = 1 set  @fecha_pago = DATEADD(day,1,@fecha_pago)  --Esta funcion sirve para sumarle un mes, año, dia, segundo, etc. a la fecha establecida
				else if @formapago = 2 set  @fecha_pago = DATEADD(week,1,@fecha_pago)
				else if @formapago = 3 set  @fecha_pago = DATEADD(week,2,@fecha_pago)
				else if @formapago = 4 set  @fecha_pago = DATEADD(MONTH,1,@fecha_pago)
				else if @formapago = 5 set  @fecha_pago = DATEADD(YEAR,1,@fecha_pago)

				insert into @t values(@fecha_pago, @p, @amortizacion_temporal, @i_temporal, @monto_temporal)
			end
		else
			begin
				insert into @t values(@fecha_pago, 0, 0, 0, @monto)
				set @monto_temporal = @monto
			end
			set @contador = @contador + 1
		END
	end


select fecha_pago, cuota, capital, interes, balance, (select sum(cuota) from @t) sum_pago, (select sum(interes) from @t) as sum_interes, 
	(select sum(capital) from @t) sum_amortizacion
  from @t as a
GO
