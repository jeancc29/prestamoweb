CREATE proc sp_pagos_siguienteid
as
declare @id int
select @id = max(d.documento) from documentos d inner join 
	tipos_registros t on d.tipo_registro_documento = t.tipo_registro
where t.renglon = 'documento' and t.descripcion = 'pago' 

if @id is null set @id = 0
set @id = @id + 1

select @id as id
GO
