CREATE proc sp_clientes_datos_resumen
@codigo_cliente int
as
declare @prestamos int
declare @prestamos_saldados int
declare @monto_restante decimal(20,2)
declare @t table(pagados int)
set nocount on
select @prestamos = count(id_registro) from documentos d inner join tipos_registros t on d.tipo_registro_documento = t.tipo_registro where codigo_usuario = @codigo_cliente and t.descripcion = 'prestamo'
	insert into @t select  
				case
					when (select sum(p.cuota) from vw_pagos_consulta p where p.id_prestamo = d.id_registro) = 0 then 1
					else 0
				end 
				from documentos d inner join tipos_registros t on d.tipo_registro_documento = t.tipo_registro
				where codigo_usuario = @codigo_cliente and t.descripcion = 'prestamo'

select @prestamos_saldados = sum(pagados) from @t
if @prestamos_saldados is null
	set @prestamos_saldados = 0

select @prestamos_saldados as prestamos_saldados, @prestamos as prestamos
GO
