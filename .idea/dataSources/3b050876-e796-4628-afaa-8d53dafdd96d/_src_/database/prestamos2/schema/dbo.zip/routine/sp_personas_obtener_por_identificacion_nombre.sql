
create proc sp_personas_obtener_por_identificacion_nombre
 @datos varchar(50)
as
set nocount on
SELECT  u.nombre,
		u.telefono,
		u.codigo_usuario,
		u.identificacion,
		u.correo 
	FROM usuarios u 
	INNER JOIN tipos_registros t 
	ON u.tipo_registro_usuario = t.tipo_registro 
WHERE estado = 1 and (u.identificacion like '%' + @datos + '%' or u.nombre  like '%' + @datos + '%')


GO
