CREATE proc sp_tipos_registros_actualizar
 @tipo_registro int = null,
 @renglon varchar(20) = null,
 @descripcion varchar(200) = null

 as

 set nocount on

 if @tipo_registro is null
	begin
		select @tipo_registro = max(tipo_registro) from tipos_registros
		if @tipo_registro is null set @tipo_registro = 0
		set @tipo_registro = @tipo_registro + 1
		insert into tipos_registros(tipo_registro, renglon, descripcion) values(@tipo_registro, @renglon, @descripcion)
		select 'Se ha guardado correctamente' as info, 0 as error
	end
else
	begin
		update tipos_registros set renglon = @renglon, descripcion = @descripcion where tipo_registro = @tipo_registro
		select 'Se ha actualizado correctamente' as info, 0 as error
	end


GO
