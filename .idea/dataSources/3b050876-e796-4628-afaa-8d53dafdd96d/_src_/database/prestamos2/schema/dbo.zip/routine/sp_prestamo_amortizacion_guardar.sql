CREATE proc sp_prestamo_amortizacion_guardar
 @cuotas int = null,
 @monto decimal(20, 2) = null,
 @tipo_prestamo int = null,
 @tasa int = null,
 @idPrestamo int = null,
 @formapago int = null,
 @fecha_pago datetime2 = getdate

 as


declare @p decimal(20, 12)
declare @i decimal(2, 2)
declare @t table(pago decimal(20,2), interes decimal(20, 2), amortizacion decimal(20, 2), saldo decimal(20, 2))

declare @i_temporal decimal(20, 10) = 0
declare @monto_temporal decimal(20, 10) = 1
declare @amortizacion_temporal decimal(20, 10) = 0
declare @contador int = 0





-- set @a = 4000 *  ((0.42/6) / ( (1-power((1+(0.42/6)), -6) )))

/************************* METODO SOLUTO(Pago e interes fijos) ********************************/
if @tipo_prestamo = 1
	begin
		set @i = cast(@tasa as float) / cast(100 as float)
		set @i_temporal = @monto * (@i / @cuotas)
		set @p = @i_temporal + (cast(@monto as float) / cast(@cuotas as float))
		
		

		WHILE (@contador <= @cuotas)
		BEGIN
		if @contador > 0
			begin
				set @amortizacion_temporal = @p - @i_temporal;
				set @monto_temporal = @monto_temporal - @amortizacion_temporal
				 
				if @formapago = 1 set  @fecha_pago = DATEADD(day,1,@fecha_pago)  --Esta funcion sirve para sumarle un mes, año, dia, segundo, etc. a la fecha establecida
				else if @formapago = 2 set  @fecha_pago = DATEADD(week,1,@fecha_pago)
				else if @formapago = 3 set  @fecha_pago = DATEADD(week,2,@fecha_pago)
				else if @formapago = 4 set  @fecha_pago = DATEADD(MONTH,1,@fecha_pago)
				else if @formapago = 5 set  @fecha_pago = DATEADD(YEAR,1,@fecha_pago)

				insert into amortizacion(fecha_pago, cuota, capital, interes, balance , id_prestamo, numero_cuota) values(@fecha_pago, @p, @amortizacion_temporal, @i_temporal, @monto_temporal, @idPrestamo, @contador)
			end
		else
			begin
				--insert into amortizacion(fecha_pago, cuota, capital, interes, balance , id_prestamo) values(@fecha_pago, 0, 0, 0, @monto, @idPrestamo)
				set @monto_temporal = @monto
			end
			set @contador = @contador + 1
		END
	end


/************************* METODO INSOLUTO(Amortizacion francesa) ********************************/
if @tipo_prestamo = 2
	begin
		set @i = cast(@tasa as float) / cast(100 as float)
		set @p = @monto *  ((@i/@cuotas) / ( (1-power((1+(@i/@cuotas)), -@cuotas) ))) 

		/*declare @i_temporal decimal(20, 10) = 0
		declare @monto_temporal decimal(20, 10) = 1
		declare @amortizacion_temporal decimal(20, 10) = 0
		declare @contador int = 0 */

		WHILE (@contador <= @cuotas)
		BEGIN
		if @contador > 0
			begin
				set @i_temporal = @monto_temporal * (@i / @cuotas)
				set @amortizacion_temporal = @p - @i_temporal;
				set @monto_temporal = @monto_temporal - @amortizacion_temporal

				if @formapago = 1 set  @fecha_pago = DATEADD(day,1,@fecha_pago)  --Esta funcion sirve para sumarle un mes, año, dia, segundo, etc. a la fecha establecida
				else if @formapago = 2 set  @fecha_pago = DATEADD(week,1,@fecha_pago)
				else if @formapago = 3 set  @fecha_pago = DATEADD(week,2,@fecha_pago)
				else if @formapago = 4 set  @fecha_pago = DATEADD(MONTH,1,@fecha_pago)
				else if @formapago = 5 set  @fecha_pago = DATEADD(YEAR,1,@fecha_pago)

				insert into amortizacion(fecha_pago, cuota, capital, interes, balance , id_prestamo, numero_cuota) values(@fecha_pago, @p, @amortizacion_temporal, @i_temporal, @monto_temporal, @idPrestamo, @contador)
				--insert into amortizacion values(@p, @i_temporal, @amortizacion_temporal, @monto_temporal)
			end
		else
			begin
				--insert into amortizacion(fecha_pago, cuota, capital, interes, balance , id_prestamo) values(@fecha_pago, 0, 0, 0, @monto, @idPrestamo)
				set @monto_temporal = @monto
			end
			set @contador = @contador + 1
		END
	end




/************************* METODO AMORTIZACION FIJA(Amortizacion Aleman) ********************************/
if @tipo_prestamo = 3
	begin
		set @i = cast(@tasa as float) / cast(100 as float)
		set @p = @i_temporal + (cast(@monto as float) / cast(@cuotas as float))
		set @amortizacion_temporal = @p - @i_temporal;

		/*declare @i_temporal decimal(20, 10) = 0
		declare @monto_temporal decimal(20, 10) = 1
		declare @amortizacion_temporal decimal(20, 10) = 0
		declare @contador int = 0 */

		WHILE (@contador <= @cuotas)
		BEGIN
		if @contador > 0
			begin
				set @i_temporal = @monto_temporal * (@i / @cuotas)
				set @p = @i_temporal + @amortizacion_temporal
				set @monto_temporal = @monto_temporal - @amortizacion_temporal
				if @formapago = 1 set  @fecha_pago = DATEADD(day,1,@fecha_pago)  --Esta funcion sirve para sumarle un mes, año, dia, segundo, etc. a la fecha establecida
				else if @formapago = 2 set  @fecha_pago = DATEADD(week,1,@fecha_pago)
				else if @formapago = 3 set  @fecha_pago = DATEADD(week,2,@fecha_pago)
				else if @formapago = 4 set  @fecha_pago = DATEADD(MONTH,1,@fecha_pago)
				else if @formapago = 5 set  @fecha_pago = DATEADD(YEAR,1,@fecha_pago)

				insert into amortizacion(fecha_pago, cuota, capital, interes, balance , id_prestamo, numero_cuota) values(@fecha_pago, @p, @amortizacion_temporal, @i_temporal, @monto_temporal, @idPrestamo, @contador)
				--insert into amortizacion values(@p, @i_temporal, @amortizacion_temporal, @monto_temporal)
			end
		else
			begin
				--insert into amortizacion(fecha_pago, cuota, capital, interes, balance , id_prestamo) values(@fecha_pago, 0, 0, 0, @monto, @idPrestamo)
				set @monto_temporal = @monto
			end
			set @contador = @contador + 1
		END
	end


--select 'La amortizacion se ha guardado correctamente'
GO
