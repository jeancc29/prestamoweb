CREATE proc [dbo].[clientes_actualizar]
@codigo_usuario int = null,
@nombre varchar(200) = null,
@sexo varchar(20) = null,
@identificacion varchar(20) = null,
@telefono varchar(20) = null,
@direccion varchar(500) = null,
@fecha_nacimiento date = null,
@correo varchar(200) = null,
@idSector int = null,
@tipo_usuario int = 1

as

set nocount on
declare @tipo_registro_usuario int
if @tipo_usuario = 1
	select @tipo_registro_usuario = tipo_registro from tipos_registros where renglon = 'usuario' and descripcion = 'Cliente'
else if @tipo_usuario = 2
	select @tipo_registro_usuario = tipo_registro from tipos_registros where renglon = 'usuario' and descripcion = 'Garante'
else 
	select @tipo_registro_usuario = tipo_registro from tipos_registros where renglon = 'usuario' and descripcion = 'Empleado'

if @codigo_usuario is not null
	begin
		update usuarios 
			set nombre = @nombre, 
				sexo = @sexo, 
				identificacion = @identificacion, 
				telefono = @telefono,
				fecha_nacimiento = @fecha_nacimiento,
				tipo_registro_sector = @idSector,
				tipo_registro_usuario = @tipo_registro_usuario,
				direccion = @direccion,
				correo = @correo
				where codigo_usuario = @codigo_usuario

			select 'El cliente se ha actualizado correctamente', @direccion as direccion
	end
else
	begin
		select @codigo_usuario = max(codigo_usuario) from usuarios
		if @codigo_usuario is null set @codigo_usuario = 0
		set @codigo_usuario = @codigo_usuario + 1
		insert into usuarios
			(codigo_usuario, nombre, sexo, identificacion, telefono, fecha_nacimiento, tipo_registro_sector, tipo_registro_usuario, direccion, correo)
			values(@codigo_usuario, @nombre, @sexo, @identificacion, @telefono, @fecha_nacimiento, @idSector, @tipo_registro_usuario, @direccion, @correo)

		select 'El cliente se ha insertado correctamente'
	end


GO
