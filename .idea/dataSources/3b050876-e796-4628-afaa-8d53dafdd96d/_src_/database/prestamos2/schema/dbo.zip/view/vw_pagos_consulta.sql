CREATE view vw_pagos_consulta
as




select idAmortizacion, 
			fecha_pago, 
			numero_cuota,
			cuota = 
				case 
					when (select  (a.cuota - sum(d.monto)) from documentos d where d.id_registro_afecta = a.id_prestamo and d.idAmortizacion = a.idAmortizacion) is null then a.cuota
					--when (select  (a.cuota - sum(d.monto)) from documentos d where d.id_registro_afecta = a.id_prestamo and d.idAmortizacion = a.idAmortizacion) = 0 then a.cuota
					else (select  (a.cuota - sum(d.monto)) from documentos d where d.id_registro_afecta = a.id_prestamo and d.idAmortizacion = a.idAmortizacion) 
				end, 
			capital, 
			interes, 
			balance, 
			id_prestamo,
			(select mora from documentos d where d.id_registro = a.id_prestamo) as mora_porcentaje,
			mora_perdonada = 
				case
					when (select top 1 mora_perdonada from documentos d where d.idAmortizacion = a.idAmortizacion) is null then 0
					else (select top 1 mora_perdonada from documentos d where d.idAmortizacion = a.idAmortizacion)
				end,
			 pagado =
				case
					when (select d.idAmortizacion from documentos d where   d.id_registro_afecta = a.id_prestamo and d.idAmortizacion = a.idAmortizacion group by idAmortizacion, d.mora having sum(d.monto) >= (a.cuota+d.mora)) is null then 'Pendiente'
					else 'Pagado'
				end,
			interes_pagado = 
				case 
					when (select sum(d.monto) from documentos d where d.id_registro_afecta = a.id_prestamo and d.idAmortizacion = a.idAmortizacion) > a.interes then a.interes
					when (select sum(d.monto) from documentos d where d.id_registro_afecta = a.id_prestamo and d.idAmortizacion = a.idAmortizacion) is null then 0
					else (select  (a.interes - sum(d.monto)) from documentos d where d.id_registro_afecta = a.id_prestamo and d.idAmortizacion = a.idAmortizacion) 
				end
	from amortizacion a


GO
