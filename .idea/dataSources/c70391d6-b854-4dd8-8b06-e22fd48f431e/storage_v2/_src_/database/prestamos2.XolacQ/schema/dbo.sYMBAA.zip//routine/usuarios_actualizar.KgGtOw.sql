CREATE proc usuarios_actualizar
@codigo_usuario int = null,
@nombre varchar(200) = null,
@sexo varchar(20) = null,
@identificacion varchar(20) = null,
@telefono varchar(20) = null

as

set nocount on
if @codigo_usuario is not null
	begin
		update usuarios 
			set nombre = @nombre, sexo = @sexo, identificacion = @identificacion, telefono = @telefono 
				where codigo_usuario = @codigo_usuario
	end
else
	begin
		select @codigo_usuario = max(codigo_usuario) from usuarios
		if @codigo_usuario is null set @codigo_usuario = 0
		set @codigo_usuario = @codigo_usuario + 1
		insert into usuarios
			(codigo_usuario, nombre, sexo, identificacion, telefono)
			values(@codigo_usuario, @nombre, @sexo, @identificacion, @telefono)
	end


	select * from usuarios
GO

