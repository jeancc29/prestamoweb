create proc sp_usuarios_actualizar
@idUsuario int = null,
@usuario varchar(50) = null,
@clave varchar(255) = null,
@horaEntrada time = '',
@horaSalida time = '',
@idNivel int = 1
as

if not exists(select idUsuario from usuarios where idUsuario = @idUsuario)
	begin
		insert into usuarios
			(
				idUsuario,
				usuario,
				clave,
				horaEntrada,
				horaSalida,
				idNivel
			)
		values
			(
				@idUsuario,
				@usuario,
				@clave,
				@horaEntrada,
				@horaSalida,
				@idNivel
			)
	end
else
	begin
		update usuarios set
			usuario = @usuario,
			clave = @clave,
			horaEntrada = @horaEntrada,
			horaSalida = @horaSalida,
			idNivel = @idNivel
		where idUsuario = @idUsuario
	end
GO
