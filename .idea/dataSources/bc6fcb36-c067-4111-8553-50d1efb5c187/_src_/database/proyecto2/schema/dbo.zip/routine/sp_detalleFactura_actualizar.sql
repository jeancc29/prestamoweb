create proc sp_detalleFactura_actualizar
@numFactura int = null,
@idProducto int  = null,
@cantidad float = null,
@precio decimal(20, 2) = null,
@itbis decimal(20, 2) = null,
@descuento_porciento int,
@descuento_valor decimal(10, 2)

as

if not exists(select numFactura from detalleFacturas where numFactura = @numFactura and idProducto = @idProducto)
	begin
		insert into detalleFacturas
			(
				numFactura,
				idProducto,
				cantidad,
				precio,
				itbis,
				descuento_porciento,
				descuento_valor
			)
		values
			(
				@numFactura,
				@idProducto,
				@cantidad,
				@precio,
				@itbis,
				@descuento_porciento,
				@descuento_valor
			)
	end
else
	begin
		update detalleFacturas set
				idProducto = @idProducto,
				cantidad = @cantidad,
				precio = @precio,
				itbis = @itbis,
				descuento_porciento = @descuento_porciento,
				descuento_valor = @descuento_valor
			where numFactura = @numFactura and idProducto = @idProducto
	end
GO
