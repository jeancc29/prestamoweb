create view vw_suplidores
as
select t.*, s.*, r.rnc from terceros t
inner join suplidores s on t.idTercero = s.idSuplidor
inner join rnc r on r.idRnc = s.idRnc
GO
