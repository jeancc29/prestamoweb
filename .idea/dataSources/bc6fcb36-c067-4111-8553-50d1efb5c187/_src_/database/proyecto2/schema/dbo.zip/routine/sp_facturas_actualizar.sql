create proc sp_facturas_actualizar
@numFactura int = null,
@idCliente int = null,
@fecha datetime2 = null,
@monto_sin_itbis decimal(20, 2) = null,
@itbis decimal(20, 2) = null,
@devuelta decimal(20, 2) = null,
@idUsuario int = null,
@monto_con_itbis decimal(20, 2) = null,
@ncf varchar(25) = null

as

if not exists(select numFactura from facturas where numFactura = @numFactura)
	begin
		insert into facturas
			(
				numFactura,
				idCliente,
				fecha,
				monto_sin_itbis,
				itbis,
				devuelta,
				idUsuario,
				monto_con_itbis,
				ncf
			)
		values
			(
				@numFactura,
				@idCliente,
				@fecha,
				@monto_sin_itbis,
				@itbis,
				@devuelta,
				@idUsuario,
				@monto_con_itbis,
				@ncf
			)
	end
else
	begin
		update facturas set
			idCliente = @idCliente,
				fecha = @fecha,
				monto_sin_itbis = @monto_sin_itbis,
				itbis = @itbis,
				devuelta = @devuelta,
				idUsuario = @idUsuario,
				monto_con_itbis = @monto_con_itbis,
				ncf = @ncf
			where numFactura = @numFactura
	end
GO
