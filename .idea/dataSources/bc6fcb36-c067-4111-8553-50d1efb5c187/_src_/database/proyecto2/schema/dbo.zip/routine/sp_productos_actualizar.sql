CREATE proc sp_productos_actualizar
@idProducto int = null,
@descripcion varchar(200) = '',
@idSuplidor int = null,
@idCategoria int = null,
@imagen varchar(200) = '',
@idMarca int = null,
@idDepartamento int = null,
@ubicacion varchar(300) = '',
@punreo int = null,
@fechaVencimiento date = null,
@precioVenta decimal(20, 2) = null,
@canExi decimal(14, 2) = null,
@idUnidad int = null

as

if not exists(select idProducto from productos where idProducto = @idProducto)
	begin
		insert into productos
			(
				idProducto,
				descripcion,
				idSuplidor,
				idCategoria,
				imagen,
				idMarca,
				idDepartamento,
				ubicacion,
				punreo,
				fechaVencimiento,
				precioVenta,
				canExi,
				idUnidad
			)
		values
			(
				@idProducto,
				@descripcion,
				@idSuplidor,
				@idCategoria,
				@imagen,
				@idMarca,
				@idDepartamento,
				@ubicacion,
				@punreo,
				@fechaVencimiento,
				@precioVenta,
				@canExi,
				@idUnidad
			)
	end
else
	begin
		update productos set
			descripcion = @descripcion,
			idSuplidor = @idSuplidor,
			idCategoria = @idCategoria,
			imagen = @imagen,
			idMarca = @idMarca,
			idDepartamento = @idDepartamento,
			ubicacion = @ubicacion,
			punreo = @punreo,
			fechaVencimiento = fechaVencimiento,
			precioVenta = @precioVenta,
			canExi = @canExi
		where idProducto = @idProducto
	end
GO
